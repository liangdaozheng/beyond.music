//07.js Worker任务
postMessage("涛哥你要前天汉堡放在办公室");
onmessage = function(e){
  console.log(":(__"+e.data);
}