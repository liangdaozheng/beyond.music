//创建执行5s程序
//1:创建开始时间 
var start = new Date().getTime();
do{
 //2:在循环中创建结束时间 
 var end = new Date().getTime();
 //3:如果结束时间减去开始时间==5000 秒
}while(end - start < 5000);
console.log("执行完成耗时任务....");