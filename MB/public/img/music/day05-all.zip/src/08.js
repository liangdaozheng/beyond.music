//1:接收数值
onmessage = function(e){
  var n = e.data;
  //2:计算累加和 
  var sum = 0;
  for(var i=1;i<=n;i++){
    sum+=i;
  }
  //3:返回数据
  postMessage(sum);
}