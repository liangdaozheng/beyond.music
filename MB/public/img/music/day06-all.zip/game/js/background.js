//src/background.js
//1:添加绘制背景函数
function drawBackground(){
   ctx2.drawImage(bgPic,0,0);
}
//2:将background.js 添加index.html中